<?php
// src/Repository/VacationTakenRepository.php
namespace App\Repository;

use App\Entity\VacationTaken;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class VacationTakenRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, VacationTaken::class);
    }

    // Método para encontrar un día de vacaciones tomado por su ID
    public function find($id, $lockMode = null, $lockVersion = null): ?VacationTaken
    {
        return parent::find($id, $lockMode, $lockVersion);
    }

    // Método para encontrar todos los días de vacaciones tomados
    public function findAll(): array
    {
        return parent::findAll();
    }

    // Método para encontrar días de vacaciones tomados por usuario
    public function findByUser($userId): array
    {
        return $this->createQueryBuilder('vt')
            ->andWhere('vt.user = :userId')
            ->setParameter('userId', $userId)
            ->getQuery()
            ->getResult();
    }

    // Puedes agregar más métodos personalizados según tus necesidades
}

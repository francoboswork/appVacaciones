<?php
// src/Entity/VacationTaken.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'vacations_taken')]
class VacationTaken
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(name: 'user_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    private $user;

    #[ORM\ManyToOne(targetEntity: VacationRequest::class)]
    #[ORM\JoinColumn(name: 'vacation_request_id', referencedColumnName: 'id', onDelete: 'CASCADE')]
    private $vacationRequest;

    #[ORM\Column(type: 'date')]
    private $date;

    #[ORM\Column(type: 'datetime', options: ['default' => 'CURRENT_TIMESTAMP'])]
    private $createdAt;

    // Getters y setters
    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;
        return $this;
    }

    public function getVacationRequest(): ?VacationRequest
    {
        return $this->vacationRequest;
    }

    public function setVacationRequest(?VacationRequest $vacationRequest): self
    {
        $this->vacationRequest = $vacationRequest;
        return $this;
    }

    public function getDate(): \DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;
        return $this;
    }

    public function getCreatedAt(): \DateTimeInterface
    {
        return $this->createdAt;
    }
}

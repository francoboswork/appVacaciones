<?php
// src/Controller/UserController.php
namespace App\Controller;

use App\Entity\User;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    #[Route('/users', name: 'user_list', methods: ['GET'])]
    public function list(): Response
    {
        $users = $this->userRepository->findAllUsers();

        // Mapea los datos de los usuarios a un array para devolver solo la información necesari
        $result = [];
        foreach ($users as $user) {
            $result[] = [
                'id' => $user->getId(),
                'username' => $user->getUsername(),
                'role' => $user->getRole(),
                'vacationDays' => $user->getVacationDays(),
                'vacationsTaken' => $user->getVacationsTaken(),
                // Agrega más campos según sea necesario
            ];
        }

        return $this->json($result);
    }

    #[Route('/users', name: 'user_create', methods: ['POST'])]
    public function create(Request $request): Response
    {
        $data = json_decode($request->getContent(), true);

        $user = new User();
        $user->setUsername($data['username']);
        $user->setPassword($data['password']);
        $user->setRole($data['role'] ?? 'default');
        $user->setVacationDays($data['vacationDays'] ?? 30);
        $user->setVacationsTaken(0);

        $this->userRepository->persist($user); // Cambia a usar el repositorio

        return $this->json($user, Response::HTTP_CREATED);
    }

    #[Route('/users/{id}', name: 'user_update', methods: ['PUT'])]
    public function update(Request $request, int $id): Response
    {
        $user = $this->userRepository->find($id);
        if (!$user) {
            return $this->json(['error' => 'User not found'], Response::HTTP_NOT_FOUND);
        }

        $data = json_decode($request->getContent(), true);
        if (isset($data['username'])) {
            $user->setUsername($data['username']);
        }
        if (isset($data['password'])) {
            $user->setPassword($data['password']);
        }
        if (isset($data['role'])) {
            $user->setRole($data['role']);
        }
        if (isset($data['vacationDays'])) {
            $user->setVacationDays($data['vacationDays']);
        }

        $this->userRepository->flush(); // Cambia a usar el repositorio

        return $this->json($user);
    }

    #[Route('/users/{id}', name: 'user_delete', methods: ['DELETE'])]
    public function delete(int $id): Response
    {
        $user = $this->userRepository->find($id);
        if (!$user) {
            return $this->json(['error' => 'User not found'], Response::HTTP_NOT_FOUND);
        }

        $this->userRepository->remove($user); // Cambia a usar el repositorio
        $this->userRepository->flush(); // Cambia a usar el repositorio

        return $this->json(['message' => 'User deleted successfully']);
    }
}

<?php
// src/Controller/VacationTakenController.php
namespace App\Controller;

use App\Entity\VacationTaken;
use App\Entity\User; // Asegúrate de importar la clase User
use App\Entity\VacationRequest; // Asegúrate de importar la clase VacationRequest
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VacationTakenController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    #[Route('/vacation_taken', name: 'vacation_taken_list')]
    public function list(): Response
    {
        $vacationsTaken = $this->entityManager->getRepository(VacationTaken::class)->findAll();

        return $this->render('vacation_taken/list.html.twig', [
            'vacations_taken' => $vacationsTaken,
        ]);
    }

    #[Route('/vacation_taken/new', name: 'vacation_taken_create', methods: ['GET', 'POST'])]
    public function create(Request $request): Response
    {
        $vacationTaken = new VacationTaken();

        if ($request->isMethod('POST')) {
            $userId = $request->request->get('user_id'); // Obtener ID del usuario
            $vacationRequestId = $request->request->get('vacation_request_id'); // Obtener ID de la solicitud de vacaciones
            $date = new \DateTime($request->request->get('date')); // Obtener fecha de vacaciones

            // Obtener el usuario y la solicitud de vacaciones
            $user = $this->entityManager->getRepository(User::class)->find($userId);
            $vacationRequest = $this->entityManager->getRepository(VacationRequest::class)->find($vacationRequestId);

            if (!$user || !$vacationRequest) {
                $this->addFlash('error', 'User or vacation request not found.');
                return $this->redirectToRoute('vacation_taken_create');
            }

            // Establecer los datos del objeto VacationTaken
            $vacationTaken->setUser($user);
            $vacationTaken->setVacationRequest($vacationRequest);
            $vacationTaken->setDate($date);
            $vacationTaken->setCreatedAt(new \DateTime()); // Establecer fecha de creación

            $this->entityManager->persist($vacationTaken);
            $this->entityManager->flush();

            $this->addFlash('success', 'Vacation day recorded successfully.');
            return $this->redirectToRoute('vacation_taken_list'); // Redirigir después de crear
        }

        return $this->render('vacation_taken/create.html.twig', [
            'vacationTaken' => $vacationTaken,
        ]);
    }

    #[Route('/vacation_taken/{id}/delete', name: 'vacation_taken_delete', methods: ['POST'])]
    public function delete(VacationTaken $vacationTaken): Response
    {
        $this->entityManager->remove($vacationTaken);
        $this->entityManager->flush();

        $this->addFlash('success', 'Vacation day deleted successfully.');
        return $this->redirectToRoute('vacation_taken_list'); // Redirigir después de eliminar
    }
}

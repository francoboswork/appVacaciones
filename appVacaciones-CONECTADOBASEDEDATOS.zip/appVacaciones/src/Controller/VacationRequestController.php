<?php
// src/Controller/VacationRequestController.php
namespace App\Controller;

use App\Entity\VacationRequest;
use App\Entity\User; // Asegúrate de importar la clase User
use App\Repository\VacationRequestRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class VacationRequestController extends AbstractController
{
    private $entityManager;
    private $vacationRequestRepository;

    public function __construct(EntityManagerInterface $entityManager, VacationRequestRepository $vacationRequestRepository)
    {
        $this->entityManager = $entityManager;
        $this->vacationRequestRepository = $vacationRequestRepository;
    }

    #[Route('/vacation_requests', name: 'vacation_request_list')]
    public function list(): Response
    {
        $vacationRequests = $this->vacationRequestRepository->findAll();

        // return $this->render('vacation_request/list.html.twig', [
        //     'vacation_requests' => $vacationRequests,
        // ]);
        return $this->json($vacationRequests);

    }

    #[Route('/vacation_requests/new', name: 'vacation_request_create', methods: ['GET', 'POST'])]
    public function create(Request $request): Response
    {
        $vacationRequest = new VacationRequest();

        if ($request->isMethod('POST')) {
            $userId = $request->request->get('user_id'); // Obtener ID del usuario
            $user = $this->entityManager->getRepository(User::class)->find($userId); // Obtener el usuario

            if (!$user) {
                $this->addFlash('error', 'User not found.');
                return $this->redirectToRoute('vacation_request_list');
            }

            $startDate = new \DateTime($request->request->get('start_date'));
            $endDate = new \DateTime($request->request->get('end_date'));

            if ($startDate > $endDate) {
                $this->addFlash('error', 'Start date cannot be after end date.');
                return $this->redirectToRoute('vacation_request_create');
            }

            $vacationRequest->setUser($user);
            $vacationRequest->setStartDate($startDate);
            $vacationRequest->setEndDate($endDate);
            $vacationRequest->setStatus('pending'); // Establecer estado por defecto
            $vacationRequest->setType($request->request->get('type'));
            $vacationRequest->setCreatedAt(new \DateTime()); // Establecer fecha de creación
            $vacationRequest->setUpdatedAt(new \DateTime()); // Establecer fecha de actualización

            $this->entityManager->persist($vacationRequest);
            $this->entityManager->flush();

            $this->addFlash('success', 'Vacation request created successfully.');
            return $this->redirectToRoute('vacation_request_list'); // Redirigir después de crear
        }

        return $this->render('vacation_request/create.html.twig', [
            'vacationRequest' => $vacationRequest,
        ]);
    }

    #[Route('/vacation_requests/{id}/edit', name: 'vacation_request_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, VacationRequest $vacationRequest): Response
    {
        if ($request->isMethod('POST')) {
            $startDate = new \DateTime($request->request->get('start_date'));
            $endDate = new \DateTime($request->request->get('end_date'));

            if ($startDate > $endDate) {
                $this->addFlash('error', 'Start date cannot be after end date.');
                return $this->redirectToRoute('vacation_request_edit', ['id' => $vacationRequest->getId()]);
            }

            $vacationRequest->setStartDate($startDate);
            $vacationRequest->setEndDate($endDate);
            $vacationRequest->setType($request->request->get('type'));
            $vacationRequest->setUpdatedAt(new \DateTime()); // Actualiza la fecha

            $this->entityManager->flush();

            $this->addFlash('success', 'Vacation request updated successfully.');
            return $this->redirectToRoute('vacation_request_list'); // Redirigir después de editar
        }

        return $this->render('vacation_request/edit.html.twig', [
            'vacationRequest' => $vacationRequest,
        ]);
    }
}

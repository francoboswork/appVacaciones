<?php
namespace App\Command;

use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

#[AsCommand(
    name: 'app:check-database-connection',
    description: 'Check the database connection status.',
)]
class DatabaseConnectionCheckCommand extends Command
{
    private EntityManagerInterface $entityManager;
    private string $databaseUrl; // Añadir propiedad para la URL de la base de datos

    public function __construct(EntityManagerInterface $entityManager, string $databaseUrl) // Aceptar el argumento
    {
        parent::__construct();
        $this->entityManager = $entityManager;
        $this->databaseUrl = $databaseUrl; // Guardar el valor
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        try {
            $connection = $this->entityManager->getConnection();

            // Verifica si la conexión está activa
            if ($connection->isConnected()) {
                $output->writeln('Conexión a la base de datos exitosa.');
            } else {
                $output->writeln('La conexión a la base de datos no está activa.');
            }
        } catch (\Exception $e) {
            $output->writeln('Error de conexión: ' . $e->getMessage());
            return Command::FAILURE;
        }

        return Command::SUCCESS;
    }
}

<?php
// src/Repository/UserRepository.php
namespace App\Repository;

use App\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

class UserRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, User::class);
    }

    // Método para buscar un usuario por su nombre de usuario
    public function findByUsername(string $username): ?User
    {
        return $this->createQueryBuilder('u')
            ->andWhere('u.username = :username')
            ->setParameter('username', $username)
            ->getQuery()
            ->getOneOrNullResult();
    }

    // Método para obtener todos los usuarios que tienen días de vacaciones disponibles
    public function findAllUsersWithVacations(): array
    {
        return $this->createQueryBuilder('u')
            ->andWhere('u.vacationDays > 0')
            ->getQuery()
            ->getResult();
    }

    // Método para obtener todos los usuarios
    public function findAllUsers(): array
    {
        return $this->findAll();
    }

    // Método para persistir un nuevo usuario
    public function save(User $user): void
    {
        $this->getEntityManager()->persist($user); 
    }

    // Método para ejecutar el flush en el EntityManager
    public function flush(): void
    {
        $this->getEntityManager()->flush();
    }

    // Método para eliminar un usuario
    public function remove(User $user): void
    {
        $this->getEntityManager()->remove($user);
    }

    // Otros métodos personalizados pueden ir aquí...
}

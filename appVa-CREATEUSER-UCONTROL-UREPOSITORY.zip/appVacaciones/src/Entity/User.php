<?php
// src/Entity/User.php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
#[ORM\Table(name: 'users')]
class User
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private $username;

    #[ORM\Column(type: 'string', length: 255)]
    private $password;

    #[ORM\Column(type: 'string', length: 50, options: ['default' => 'default'])]
    private $role;

    #[ORM\Column(type: 'integer', options: ['default' => 30])]
    private $vacationDays;

    #[ORM\Column(type: 'integer', options: ['default' => 0])]
    private $vacationsTaken;

    // Getters y setters
    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUsername(): string
    {
        return $this->username;
    }

    public function setUsername(string $username): self
    {
      
        $this->username = $username;
        return $this;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        
        $this->password = $password;
        return $this;
    }

    public function getRole(): string
    {
        return $this->role;
    }

    public function setRole(string $role): self
    {
        $this->role = $role;
        return $this;
    }

    public function getVacationDays(): int
    {
        return $this->vacationDays;
    }

    public function setVacationDays(int $vacationDays): self
    {
      
        $this->vacationDays = $vacationDays;
        return $this;
    }

    public function getVacationsTaken(): int
    {
        return $this->vacationsTaken;
    }

    public function setVacationsTaken(int $vacationsTaken): self
    {
       
        $this->vacationsTaken = $vacationsTaken;
        return $this;
    }
}

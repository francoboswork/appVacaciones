<?php
// src/Controller/UserController.php
namespace App\Controller;

use App\Entity\User;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class UserController extends AbstractController
{
    private $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    #[Route('/users', name: 'user_list', methods: ['GET'])]
    public function list(): Response
    {
        $users = $this->userRepository->findAllUsers();

        return $this->render('user/list.html.twig', [
            'users' => $users,
        ]);
    }

    #[Route('/users/new', name: 'user_create', methods: ['GET', 'POST'])]
    public function create(Request $request): Response
    {
        if ($request->isMethod('POST')) {
            //$data = json_decode($request->getContent(), true);
            $data = $request->request->all(); 
            $user = new User();
            $user->setUsername($data['username']);
            $user->setPassword($data['password']);
            $user->setRole($data['role'] ?? 'default');
            $user->setVacationDays($data['vacationDays'] ?? 30);
            $user->setVacationsTaken(0);
 // Persistir el nuevo usuario
            $this->userRepository->save($user);
            $this->userRepository->flush(); //guardar cambios
            return $this->redirectToRoute('user_list'); // Redirige a la lista de usuarios
        }

        return $this->render('user/create.html.twig');
    }

    #[Route('/users/{id}/edit', name: 'user_update', methods: ['GET', 'PUT'])]
    public function update(Request $request, int $id): Response
    {
        $user = $this->userRepository->find($id);
        if (!$user) {
            return $this->json(['error' => 'User not found'], Response::HTTP_NOT_FOUND);
        }

        if ($request->isMethod('PUT')) {
            $data = json_decode($request->getContent(), true);
            if (isset($data['username'])) {
                $user->setUsername($data['username']);
            }
            if (isset($data['password'])) {
                $user->setPassword($data['password']);
            }
            if (isset($data['role'])) {
                $user->setRole($data['role']);
            }
            if (isset($data['vacationDays'])) {
                $user->setVacationDays($data['vacationDays']);
            }

            $this->userRepository->flush();
            return $this->redirectToRoute('user_list'); // Redirige a la lista de usuarios
        }

        return $this->render('user/edit.html.twig', [
            'user' => $user,
        ]);
    }

    #[Route('/users/{id}', name: 'user_delete', methods: ['DELETE'])]
    public function delete(int $id): Response
    {
        $user = $this->userRepository->find($id);
        if (!$user) {
            return $this->json(['error' => 'User not found'], Response::HTTP_NOT_FOUND);
        }

        $this->userRepository->remove($user);
        $this->userRepository->flush();

        return $this->redirectToRoute('user_list'); // Redirige a la lista de usuarios
    }
}

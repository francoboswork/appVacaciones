


<?php

use App\Kernel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Dotenv\Dotenv;

require dirname(__DIR__) . '/vendor/autoload.php';

// Cargar las variables de entorno desde el archivo .env
$dotenv = new Dotenv();
$dotenv->load(dirname(__DIR__) . '/.env');

// Crear el kernel de la aplicación
$kernel = new Kernel('dev', true);
$request = Request::createFromGlobals();
$response = $kernel->handle($request);
$response->send();
$kernel->terminate($request, $response);
